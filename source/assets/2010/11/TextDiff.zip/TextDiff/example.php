<?php
// Example
require_once('TextDiff.php');
$diff = new TextDiff();
echo '<style>del{background:#fcc}ins{background:#cfc}</style>';
echo $diff->getDiff(htmlspecialchars(file_get_contents('1.txt')), htmlspecialchars(file_get_contents('2.txt')));