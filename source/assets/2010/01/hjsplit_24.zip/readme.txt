HJSplit 2.4

Description
File splitting program for Windows XP, Vista, 2000, NT, 95, 98, ME
HJSplit is able to split files of any type and any size.

Licence for use
Freeware, free for commercial and non commercial use

Licence for distribution
You can distribute this program, freely and without charge (on CD-Roms, Websites, etc.) provided that you do not change the program or the zip file in any way, that the program is clearly freeware or shareware, that you do not ask any money for the program itself.

Copyright 1995 - 2009 Freebyte.com
http://www.freebyte.com