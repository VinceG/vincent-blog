<?php

$lang = array (

'cats' => "Products List",

);
?>