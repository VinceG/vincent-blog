<?php

$lang = array(

'welcome_text' => 'ברוך הבא לאתר',
'welcome_main_text' => 'טקסט ברוך הבא שיופיע בראש העמוד',
'username' => 'שם משתמש',
'pass' => 'סיסמא',
'reg_button' => 'הרשם',
'registration_form' => 'הרשמה למערכת',
'email' => 'אימייל',
'additional_title' => 'פרטים נוספים',
'must_title' => 'פרטים דרושים',
'billing_info' => 'פרטי תשלום',
'shipping_info' => 'פרטי משלוח',
'bfirst' => 'שם פרטי',
'blast' => 'שם משפחה',
'baddress' => 'כתובת',
'bcity' => 'עיר',
'bzip' => 'מיקוד',
'bcompany' => 'חברה',
'bcountry' => 'ארץ',
'bphone' => 'טלפון',
'bcellphone' => 'פאלפון',
'bemail' => 'אימייל',
'sfirst' => 'שם פרטי',
'slast' => 'שם משפחה',
'saddress' => 'כתובת',
'scity' => 'עיר',
'szip' => 'מיקוד',
'scompany' => 'חברה',
'scountry' => 'ארץ',
'sphone' => 'טלפון',
'scellphone' => 'פאלפון',
'semail' => 'אימייל',
'required' => 'מידע דרוש',
'must_register' => 'הינך חייב להתחבר או להרשם למערכת',


'err_no_username' => 'אנא מלא את שדה שם המשתמש',
'err_no_password' => 'אנא מלא את שדה הסיסמא',
'err_invalid_email' => 'אנא מלא את שדה האימייל',
'err_invalid_email_sec' => 'האימייל לא תקין',
'err_user_exists' => 'שם המשתמש הזה כבר נמצא בשימוש',
'err_email_exists' => 'כתובת אימייל זו כבר נמצאת בשימוש',
'reg_complete' => 'נרשמת בהצלחה, מעביר לעמוד הראשי',

);

?>