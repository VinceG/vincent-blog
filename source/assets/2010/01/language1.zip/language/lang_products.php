<?php

$lang = array (
'pwasaddedtocart' => "The product was added to your cart. %s to finish your order.",
'pwasaddedtocart2' => "Here",
'customdatesdesc' => "",

'newdatefromdesc' => "Click here and choose the desired date from",
'newdatetodesc' => "Click here and choose the desired date to",

'addtocarttitle' => 'Add To Cart',
'gotocarttitle' => 'Add & Go',

'prods_title' => 'Rent a GPS, Rent a projector',
'view_details' => 'More Information',
'prods_list' => 'Product List',
'prods_detail_title' => 'View Product',
'addtocart' => 'Add To Cart',
'kupa' => 'Go To Cart',
'pfrom' => 'From Date',
'pto' => 'To Date',
'contact' => 'Contact Us',
'add' => 'Add',
'pricesc' => 'The USD Exchange rate is: %s NIS. Prices includes Tax.',
'adddatenew' => 'Add >>',
'choosedate' => 'Please choose your desired dates',
'start' => 'Start Date',
'end' => 'End Date',
'close' => 'Click to close',
'moveto' => 'Click to add to cart',
'addtokupa' => 'Add to cart and view cart',
'watchsscc' => 'View Product',
'viewother' => 'View Producs',
'ccussmall' => 'Quick Contact Us!',
'viewvideos' => 'New! Click to watch video guides',
'viewvideo' => 'Click to view this video',


// NEW VIEW
'pprice_word' => 'Price Per Day',
'pprice_sale_word' => 'Sale price',
'newrightitle1' => 'General Info',
'newrightitle2' => 'Tech Info',
'newrightitle3' => 'Additional Info',
'gotocart' => 'Cart',
'calcdays' => "Total %s Days",
'calcdaysr' => "Total 1 Day",
'clicktoordernow' => 'Click To Order',
'distext' => 'Order now and get this product for the chosen dates for only %s instead of %s, %s.',
'purprice' => 'For-Sale only Product',
'purword' => 'For-Sale only Product',
'rentingword' => 'Choose the desired dates and add to cart',

'sectab1' => 'Special Products',
'sectab2' => 'Packages',
'sectab3' => 'Products on sale',
'noinfotoshow' => 'No Information',
'didnotadd' => 'Product was not added to you cart.',

'padded' => 'Product was added.',
'noidfound' => 'Product ID was not found.',
'viewprodvideo' => 'View video guides for "%s"',
'ccdesc' => 'Quick Contact Us!',
'contactu' => 'Quick Contact Us!',
'' => '',

'newcontact' => 'New Contact Us Sent',
'fromdate' => 'Start Date',
'todate' => 'End Date',


'browseproducts' => 'Browse Products',
'pquia' => 'Quantity ',
'pweekly' => 'Weekly',
'pmontly' => 'Monthly',
'addtoorder' => 'Add To Order',
'addtoorderdesc' => 'Make sure you have set the dates above',
'aday' => 'Per Day',

);
?>