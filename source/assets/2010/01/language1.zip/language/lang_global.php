<?php

$lang = array(

'redirect' => 'Operation done, Redirecting....',
'click_to_go' => 'Click here if you do not wish to wait',
'login_title' => 'Login',
'base_title' => 'Main Page',
'logout_title' => 'Logout',
'reg_title' => 'Signup',
'global_prods' => 'Products',
'cart_title' => 'Cart',
'username' => 'User Name',
'pass' => 'Password',
'login_button' => 'Login',
'must_login' => 'You must login to complete this action',
'countincart' => 'Items:',
'globalprods' => 'Products',
'globalpacks' => 'Packages',
'globallocations' => 'Destinations',
'globalprices' => 'Prices',
'globalchooseprod' => 'Choose Product',
'globalchoosepack' => 'Choose Package',
'globalchoosedest' => 'Choose Destination',
'entertosearch' => 'Search...',
'global_contact' => 'Contact Us',
'globalaboutus' => 'About Us',
'contactusbox' => 'Please fill in the information for a sales representetive to contact you',
'sendform' => 'Send >>',
'pleasewait' => 'Please Wait',
'entername' => 'Username',
'enterphone' => 'Phone',

'send' => 'Send',
'emailsent' => 'Contact Us Sent.',
'emailnotsent' => 'Error occured',
'fillallinfo' => 'Please fill in the information',

'priceforday' => 'Price Per Day',

'doreg' => 'Signup, Quickly and easily',
'dologout' => 'Logout',
'dologin' => 'Login to your account with your username and password',
'clicktoopen' => 'Click to open',
'ccsshe' => 'Click to Close',
'submitxx' => 'Click to send',
'home1' => 'Back to home page',
'do1' => 'Click to products page',
'do2' => 'Click to view cart',
'do3' => 'Click to contact us',
'date1' => 'Click to choose the from date',
'date2' => 'Click to choose the to date',
'date11' => 'From Date',
'date22' => 'To Date',
'watchss' => 'Click to view the product',
'watchxx' => 'Click to view products for this destination',
'watchsc' => 'View Product',
'addpp' => 'Click to add this product to your cart',
'aaasss' => 'There are no products in your cart',
'messagesentok' => 'Message Sent!',
'_message1' => 'Message Sent!',
'added' => "The product was added to your cart. To view your cart<a href='index.php?act=cart'>Click Here</a>.",
'agentstitle2' => 'Click to become our partner',
'global_agents' => 'Affiliates',
'formtitle2' => 'Download Forms',
'global_forms' => 'Download Forms',
'' => '',

'toptitle1' => 'Sim Cards',
'toptitle2' => 'Laptops',
'toptitle3' => 'GPS',
'toptitle4' => 'Communication',
'toptitle5' => 'Projectors',
'toptitle6' => 'Phone Communication',
'toptitle7' => 'Cameras',
'toptitle8' => 'Search....',

'footertext1' => '',
'mycarthasx' => 'Items: %s',
'onlinechatsupport' => 'Live Chat Online',
'offlinechatsupport' => 'Live Chat Offline',

// Login
'login_username' => 'Username',
'login_or' => 'OR',
'login_email' => 'Email Address',
'login_pass' => 'Password',
'login_do' => 'Login',
'loged_in_already' => "You are now logged in as <b>%s</b>. If you would like to logout then <a href='%s'>Click Here</a>.",
'loged_in_success' => 'You are logged in as <b>%s</b>, Redirection to the site index.',
'loged_out_success' => 'You are not loged out, Redirection to the site index.',
'login_desc' => "In order to be logged in to the site all you have to do is fill in the required fields below and press the 'Login' button.",
'username_blank' => 'Please enter a username',
'password_blank' => 'Please enter a password',
'username_missing' => 'There was no member found with the information provided.',
'password_mismatch' => 'Passwords does not match each other.',
'cant_logout' => 'You are not logged in so you cannot logout',
'saveinfo_ok' => 'Information saved, Redirecting to member panel.',
'missing_fields' => 'Please fill in all fields in order to register.',
'email_wrong' => 'Please provide a valid email address.',
'username_exists' => 'Sorry, That username is already in use. Please choose another one.',
'email_exists' => 'Sorry, That email address is already in use. Please choose another one.',
'regsiter_ok' => 'You are now registered, Redirecing to login page.',
'reg_desc' => "In order to register fill in the required fields below and press the 'Register' button.",
'reg_title' => 'Register',
'reg_do' => 'Register!',

'member_info_title' => 'User Information',
'member_info_desc' => 'Below are you personal user information. Please fill those out in order to proccess orders faster.',
'member_info_fname' => 'First Name',
'member_info_lname' => 'Last Name',
'member_info_company' => 'Company Name',
'member_info_address' => 'Address',
'member_info_city' => 'City',
'member_info_country' => 'Country',
'member_info_zip' => 'Zip',
'member_info_email' => 'Email Address',
'member_info_phone' => 'Phone',
'member_info_cellphone' => 'CellPhone',
'member_info_home' => 'Home Number',
'member_info_app' => 'Appt. Number',
'member_info_billing' => 'Billing Information',
'member_info_shipping' => 'Shipping Information',
'member_info_copy' => 'Shipping information is the same as billing?',
'member_info_save' => 'Save!',
'member_orders_desc' => 'Here is a list of previous orders you have made with this account and current active orders as well. You can view there status and location.',
'member_orders_title' => 'Previous Orders',


);

$lang['time_-12'] = "(GMT - 12) אניטווטוק, קווג'אליאן";
$lang['time_-11'] = "(GMT - 11) איי מידווי, סמווה";
$lang['time_-10'] = "(GMT - 10) הוואי";
$lang['time_-9']  = "(GMT - 9) אלסקה";
$lang['time_-8']  = "(GMT - 8) זמן פסיפי (US &amp; קנדה)";
$lang['time_-7']  = "(GMT - 7) זמן ההר (US &amp; קנדה)";
$lang['time_-6']  = "(GMT - 6) זמן מרכז (US &amp; קנדה), מקסיקו סיטי";
$lang['time_-5']  = "(GMT - 5) זמן מזרח (US &amp; קנדה), בוגוטה, לימה, קוויטו";
$lang['time_-4']  = "(GMT - 4) זמן אטלנטי (קנדה), קראקס, לה פס";
$lang['time_-3.5'] = "(GMT - 3) ניופאונדלנד";
$lang['time_-3']   = "(GMT - 3) ברזיל, בואנוס איירס, ג'ורג'טאון, איי פולקלנד";
$lang['time_-2']   = "(GMT - 2) מרכז-אטלנטי, איי אסנשן, הלנה הקדושה";
$lang['time_-1']   = "(GMT - 1) אזורים, איי כף וורדה";
$lang['time_0']    = "(GMT) קזבלנקה, דבלין, אדינבורו, לונדון, ליסבון, מונרוביה";
$lang['time_1']    = "(GMT + 1) ברלין, בריסל, קופנהאגן, מדריד, פריז, רומא";
$lang['time_2']    = "(GMT + 2) ישראל,קלינינגרד, דרום אפריקה, וורשה";
$lang['time_3']    = "(GMT + 3) בגדד, ריאד, מוסקובה, ניירובי";
$lang['time_3.5']  = "(GMT + 3) טהרן";
$lang['time_4']    = "(GMT + 4) אדו דאהבי, בקו, מוסקט, טביליסי";
$lang['time_4.5']  = "(GMT + 4) קבול";
$lang['time_5']    = "(GMT + 5) אקייטרינבורג, איסלאמאבד, קרצ'י, טשקנט";
$lang['time_5.5']  = "(GMT + 5) בומביי, כלכותה, מדרס, ניו דלהי";
$lang['time_6']    = "(GMT + 6) אלמתי, קולומבה, דקרה";
$lang['time_7']    = "(GMT + 7) בנגקוק, האנוי, ג'קרטה";
$lang['time_8']    = "(GMT + 8) בייג'ינג, הונג קונג, פרת', סינגפור, טייפי";
$lang['time_9']    = "(GMT + 9) אוסקה, ספורו, סיאול, טוקיו, יקוטסק";
$lang['time_9.5']  = "(GMT + 9) אדלידה, דארווין";
$lang['time_10']   = "(GMT + 10) מלבורן, פאפוה-גינאה החדשה, סידני, ולדיבוסטוק";
$lang['time_11']   = "(GMT + 11) מגדן, קלדוניה החדשה, איי שמואל";
$lang['time_12']   = "(GMT + 12) אוקלנד, וולינגטון, פיג'י, איי מרשל";

?>