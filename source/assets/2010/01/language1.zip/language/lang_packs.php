<?php

$lang = array(

'pstart' => 'Start Date',
'pend' => 'End Date',

);

?>