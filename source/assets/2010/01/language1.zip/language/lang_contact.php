<?php

$lang = array(

'name' => 'First Name',
'fname' => 'Last Name',
'phone' => 'Phone',
'email' => 'Email',
'subject' => 'Subject',
'subject0' => '-- Choose One --',
'subject1' => 'Site Bug',
'subject2' => 'Feedback/Suggestion',
'subject3' => 'Pre-Sale Questions',
'subject4' => 'Payment Questions',
'subject5' => 'Other',
'subject6' => 'Affiliate',
'titlefirst' => 'Contact Us',
'titlesec' => 'Braches Information and directions',
'location' => "Tel-Aviv Branch, Sunday - Friday 09:00 - 19:00",
'location2' => "Beit Hilel 6, Tel-Aviv 52038<br />Phone: <b>077-5250373</b><br /> Fax: <b>03-6241483</b>",
'send' => 'Send',
'hide' => 'Click To Close',
'show' => 'Clikc To Enlarge',
'scc' => 'Send!',
'emailwassent' => 'Thanks, You message was sent.',

);

?>