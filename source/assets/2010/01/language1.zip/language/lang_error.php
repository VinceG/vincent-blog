<?php

$lang = array (

'error_title' => "Error",

);
?>