<?php

$lang = array(

'welcome_text' => 'Welcome',
'welcome_main_text' => '<span style="color:#717171;font-size:13px;">
Welcome to   <span style="color:#b18d3f;font-weight:bold;">Rent Center</span> .<br /> 
You can perform orders either directly trough the site or by contacting our sales staff.<br />
All products are available for purchase and/or renting.
<br />
In you have any questions feel free to contact us.
</span>',
'welcometextsecond' => 'You can use the navigation panel to move to the section you would want to view',

'newstitle' => 'News',



'packspro' => 'Products and packages on sale',
'contactu' => 'Would you like us to contact you?',

'lowerbox1' => 'F.A.Q',
'lowerbox2' => 'How to order',
'newstitle' => 'Site News',
'ccdesc' => 'Would you like us to contact you?',

'girl' => '',
'ccus' => 'Click to contact us',
'watchp' => 'View Product',
'scroll' => 'Browse trough our products',
'help1' => 'View The F.A.Q',
'help2' => 'Learn how to use and order trough our site',
'watchps' => 'View All products',
'watchpss' => 'View All packages',


);

?>