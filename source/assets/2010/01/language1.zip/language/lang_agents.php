<?php

$lang = array(

'title' => 'Agent Account Manager',
'desctitle' => 'Dear Agent.',
'descdesc' => 'We welcome you and thank you for working in partnership with us. All you have to do now is redirect customer in one of the options supplied.',
'Logintitle' => 'You must login',
'Loginuser' => 'Username',
'Loginpass' => 'Password',
'Loginlogin' => 'Login',
'filluser' => 'Please fill in the username field',
'fillpass' => 'Please fill in the password field',
'filltitle' => 'Please fill in the agency name field',
'nouser' => 'Username doesn\'t exists in our database',
'wrongpass' => 'Password supplied does not match with the one in our records',
'loginok' => 'Login complete, Redirecting....',
'logoutok' => 'You have been logged out',
'logedintext' => "Welcome, <span style='color:#6387a9;'>%s</span> Your logged in as %s . <span style='color:#6387a9;'>(%s)</span>",
'logedintextguest' => 'Welcome guest, You are not logged in, Please log in or signup.',
'nodata' => 'There was no information found that matched your criteria.',
'Regtitle' => "Not registered yet? Do it now!",
'Regname' => 'Agency Name',
'Regurl' => 'Agency Site Address',
'Reguser' => 'Username',
'Regpass' => 'Password',
'Regreg' => 'Signup!',
'userexists' => 'Username already in use.',
'titleexists' => 'Agency is already in use.',
'infoshort' => 'You must fill in at least 3 characters in each of the fields.',
'regok' => 'Registeration completed, Redirecting....',
'noid' => 'There was an error during the operation.',
'updatecomplete' => 'Information Updated.',
'bannerstitle' => 'Dear Agent,',
'bannersdesc' => 'Click on one of the images to obtain the code you will need to implement in your site.',
'bannerstitle' => 'Dear Agent! Choose your prefered banner',
'imgalt' => 'Rental Services',
'writeyourown' => "Generate your own hyperlink, Enter the desired description and hit the 'Generate Code' button",
'extext' => 'Rental Services',
'getbcode' => 'Generate Code!',
'topbanners' => 'Horizontal Banners - Top',
'medbanners' => 'Medium Banners',
'smallbanners' => 'Small Banners',
'longbanners' => 'Vertical Banners',

'icondownloadforms' => 'Download Forms',
'iconcontact' => 'Contact Us',
'iconwow' => 'New Offers',
'iconmsgs' => 'Announcements',

);

$lang['amalot'] = <<<EOF
שותף עסקי יקר!<br /><br />

אנו מודים לך על שבחרת להצטרף לתוכנית השותפים העסקיים שלנו באתר.<br /><br />

להלן פירוט מדרג העמלות בפירוט סך חודשי:

<ol>
<li>הזמנות בסך של עד 5000 ₪ בחודש (לא כולל מע"מ) יזכו אתכם בעמלה של 20% מסך העסקאות.</li>
<li>הזמנות של עד 10,000 ₪ בחודש (לא כולל מע"מ), יזכו אתכם בעמלה של 25% מסך העסקאות.</li>
<li>הזמנות בסך של 10,000 ₪ ומעלה בחודש (לא כולל מע"מ), יזכו אתכם בעמלה של 30% מסך העסקאות.</li>
<li>תשלום העמלה יתבצע עד 15 לכל חודש עבור החודש הקודם. העמלה תחושב ע"פ סך כל העסקאות שמשויכות לחשבונכם בחודש זה, וזאת לאחר ניכוי עלויות משלוח בסך 35 ₪ ללקוח.</li>
<li>תשלום העמלה יתבצע כנגד המצאת חשבונית מס כדין לחברתנו. במידה ואינכם מורשים בהוצאת חשבוניות כנ"ל, תוכלו להשתמש בשירותי "חשבונית לשכיר" באתר www.autotax.co.il ואף לזכות בהנחה בשירות זה.</li>
<li>התשלום יכול להתבצע באמצעות העברה בנקאית לחשבונכם או באמצעות המחאה לפקודתכם שתשלח אליכם בדואר.</li>
</ol>
EOF;

?>