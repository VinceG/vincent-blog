<?php

$lang = array(

'faqtitle' => 'Frequently asked questions (F.A.Q)',

'ordertitle' => 'How To Order',

'orderp1title' => "How To Order",
'orderp2title' => "How to order and site usage",
'orderp3title' => "",
'orderp4title' => "Product Information",
'orderp5title' => "Ordering Product",
'orderp6title' => "Product Delivery",
'orderp7title' => "Product Return",


'orderp1text' => "<ol>
<li>Choose a product, Either by destination or product type</li>
<li>Choose the dates you would like to rent this product for</li>
<li>Via the cart fill in all required fields, Choose delivery method and payment method and then finalize your order.</li>
</ol>
Order is now complete. You will be contacted by a sales representative with additional details.",
'orderp2text' => "<ol>
<li>You can navigate to your desired product by one of the following</li>
<li>By Destination</li>
<li>By Product</li>
<li>By Package</li>
<li>By Phone</li>
</ol>
<br />
You can use the navigation bar to prune and sort products",
'orderp3text' => "",
'orderp4text' => "Click on any product will take you to the products page with additional information about that product.
Moreover you will see in the product page products that are related to the product your viewing and products on sale.
<br /><br />

In order to add a product to your cart, First you will need to go to the desired products page, Then choose the dates you would like to rent it for, Then hit either the 'Add to cart' Button or 'Cart' button to go to the cart afterwards.",

'orderp5text' => "",
'orderp6text' => "",
'orderp7text' => "",

);

?>