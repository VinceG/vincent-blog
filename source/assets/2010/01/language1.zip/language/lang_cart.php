<?php

$lang = array (

'cart_contents_title' => "Number of items",
'totaltopay' => 'Total',
'pricesincludestax' => 'Prices Includes Tax',
'title_userinfo' => "Order Information",
'title_user_infousername' => "You are now logged in as '%s'",
'title_guest_userinfo_link' => "Exsiting customer please login to complete the order faster",
'userinfo_title_userinfo' => "New customer",
'title_orderuser_infotitle' => "User Information",
'title_dev_and_payment' => "Billing and Shipping information",
'title_payment_dev_second' => "Shipping/Pickup information",
'title_payment_dev_second_small' => "* Choose a pickup or a shipping option",
'title_payment_title' => "Billing Information",
'creditwillbedevtorep' => "Billing information will be provided to the customer service",
'comm_more_details' => "Add any comments regarding your order",
'more_info_title' => "Additional information",
'please_choose_one' => "- -  Select  - -",
'more_info_more1' => "What country are you traveling to",
'more_info_more2' => "How did you hear about us",
'more_info_more3' => "What is the products purpose",
'iagreetoeverythinglisted' => "I have read the %s and agree to them",
'tostitle' => "Terms Of Service",
'please_choose_agree_to_TOS' => "Please make sure you selected the checkbox that you agree to the sites Terms Of Service",
'please_entercardnumber' => "Please fill in the credit card number",
'please_entercardfname' => "Please fill in the card holders first name",
'please_entercardlname' => "Please fill in the card holders last name",

'smallreco' => "(Recommended)",
'zshippingcheckbox' => 'Shipping return address different then shipping to address?',
'timetocomepickup' => 'Pickup Hours',
'timetocomepickupfrom' => 'From',
'timetocomepickupto' => 'Until',
'zshippingdesc' => 'You can enter another address that will be used as the products return address',

'whyorderwithcredit2' => "",
'whyorderwithcredit' => "",
'requiredfield' => "Required Field",

'paymentsdesc' => 'You can split the payment up to 12 payments without any interest',
'commdesc' => 'Please provide us with any additional helpful information you think we should know about.',

'emaildesc' => 'Please provide a valid email address. All information regarding the order will be emailed to that address once order is complete.',
'clienttypedesc' => 'If your a business client (company) or if you would like the invoice to be printed on a certain company name - please choose "Company" from the drop down and fill in the extra fields.',
'namedesc' => "If it's not your first purchase please provide your username and password, If it's your first time then please choose a username and password that you will be able to remember easily.",

'paymentdescoptions' => 'This site is secured with an SSL certificate which encrypts the data being sent, Payment details and credit card information are not being stored as a record in our databases, They are deleted as soon as the payment processed.
As soon as you hit the "Complete Order" button you will receive a confirmation email which contains among the rest:
1. Order confirmation that includes your order number.
2. Renting contract and agreement
3. Invoice.
Please make sure that all information provided and listed in the confirmation email is correct and keep it as a backup.
Note! - Make sure to write down the order number so in case you will need to contact us we will be able to find your order quicker in our database.',

'removefromcartdesc' => "Remove Item - Click here to remove the item from your cart",
'updatecartdesc' => "Update Item Dates - Clikc here to change the items dates, Make sure you change the dates Prior to clicking this button. After clicking the button make sure the dates were changed.",

'order_purpose' => "-- What's your order purpose? --",

'direction' => 'ltr',
'charset' => 'utf-8',

'ptitle' => 'Title',
'pq' => 'Quantity ',
'pprice' => 'Price',
'ptotal' => 'Total',
'sum' => 'Total: %s',
'choosepay' => 'Payment Method',
'payphone' => 'Trough Phone',
'paycredit' => 'Credit Card',
'paygo' => 'Complete Order',
'preordertitle' => 'Final Details',
'confirmorder' => 'Order',
'orderdone' => 'Order Complete',
'orderdonetext' => "Your order was completed and added, All you have to do now is wait for our sales department to contact you.<br />
Your Order number is <span style='padding-right:10px;color:#b18d3f;'><b>#%s</b></span> , Total: <span style='padding-right:10px;color:#b18d3f;'><b>%s (%s)</b></span>.<br />
If you have any questions or concerns please do not hesitate to contact us at *9559
<br /><br />
%s",
'pfrom' => 'From',
'pto' => 'To',
'choosepickup' => 'Pickup Method',
'pday' => 'Days',
'pdisc' => 'Discount',
'pdiscafter' => 'After Discount',
'paycheck' => 'Echeck',
'choosedest' => 'Destination',
'emptycart' => 'The Cart is empty!',
'quickreg' => 'Quick Order',
'fullreg' => 'Full Order',
'paymentheader' => 'New Customer - Fill in the required details and press the "Complete Order" button',
'fieldreq' => '* - Required',
'name' => 'Choose Username',
'password' => 'Choose Password',
'fname' => 'First Name',
'lname' => 'Last Name',
'phone' => 'Phone Number',
'fillocation' => 'Address',
'city' => 'City',
'address' => 'Address',
'zip' => 'Zipcode',
'country' => 'Country',
'cellphone' => 'Cellphone',
'fax' => 'Fax',
'ccountry' => '-- Choose Country --',
'israel' => 'Israel',
'diffaddress' => 'Different Shipping Address',
'emailf' => 'Email',
'updates' => 'I would like to receive news and updates from this site',
'comm' => 'Comment',
'payment' => 'Payment Method',
'err_no_username' => 'Please Specify a user name',
'err_usernamelong' => 'The user name chosen is too long',
'err_no_password' => 'Please enter a password',
'err_invalid_email' => 'The email entered is invalid',
'err_invalid_email_sec' => 'Invalid Email',
'err_user_exists' => 'User name is already in use',
'err_email_exists' => 'Email chosen is already in use',
'err_fillall' => 'Please fill in all required fields',
'pricesc' => 'All prices are listed in USD and includes tax',
'remove' => 'Remove Item',
'update' => 'Update Item',
'updatemonth1' => 'Click here to choose a start date for this product',
'updatemonth2' => 'Click here to choose an end date for this product',
'fullregtab' => 'Click here to proceed to the full order page',
'quickregtab' => 'Click here to move to the quick order page',
'home' => 'House Number',
'app' => 'Apartment ',
'referer' => 'How did you reach us?',
'referer0' => ' -- Choose Referer --',
'referer1' => 'סוכנות אופרן',
'referer2' => 'פרסום ב YNET',
'referer3' => 'חיפוש בגוגל',
'referer4' => 'לקוח',
'referer5' => 'אחר - אנא ציין בתיבה',
'referer6' => 'סוכנות עתיד טורס',
'nistotal' => '%s',
'coupon' => 'Coupon',
'coupondesc' => 'If you were redirected by an affiliate and you have a coupon code then enter it below',
'coupondesc2' => "Enter Coupon",
'iscompany' => 'Business customer',
'isprivate' => 'private Customer',
'isagency' => 'Agency',

'companyname' => 'Company Name',
'companyposition' => 'Company Position',
'agencyname' => 'Agency Name',
'agencyposition' => 'Position',
'agencylocation' => 'Branch',
'clienttype' => 'Customer Type',


'contactustitle' => 'Enter you details',
'leavephone' => 'Phone',
'leavename' => 'Name',
'continuebuying' => 'Continue >>',
'startdatec' => 'Start Date',
'enddatec' => 'End Date',
'days' => '# of days',
'price' => 'Price per day',
'totalnodis' => 'Total',
'dis' => 'Discount',
'totalafterdis' => 'After discount',
'removep2' => 'Remove Item',
'editp' => 'Edit Item',

'specialoffers' => 'Products On Sale',
'totalprods2' => 'Total Products',
'shipmenttype' => 'Delivery method',
'orderformt' => 'Order form',
'table1' => 'Customer Information',
'table2' => 'Shipping Information',
'table3' => 'Payment Information',
'choosedevtype' => 'Please choose your prefered delivery method',
'devtypenoinfo' => 'The chosen payment method requires additional information',
'sameasinfo' => 'Shipping information is identical to the customer information',
'completepayinfo' => 'Pleaes fill in the required payment information',
'paybyphone' => 'Complete Phone Order',
'paybyphonedesc' => 'The payment information will be handed to the sales representative',
'inyourcart' => 'In your cart',
'totalps' => 'Products',
'topdesc' => 'כאן תוכלו להשכיר מגוון מוצרים לבית לעסק או לטיול
הזמנות ניתן לבצע און ליין באתר או באמצעות נציג שירות 24/7',
'toptitle' => 'ברוכים הבאים ל RENTCENTER',
'newstitle' => 'News',

'chatonline' => "Online Support Chat",
'salesrepcontact' => 'Quick Contact Us!',

'toplinks1' => 'Home Page',
'toplinks2' => 'About Us',
'toplinks3' => 'F.A.Q',
'toplinks4' => 'Products',
'toplinks5' => 'Affiliates',
'toplinks6' => 'Download Forms',
'toplinks7' => 'Contact Us',

'loadingpleasewait' => 'Loading, Please Wait...',
'forrent' => 'Rent >>',
'priceforrent' => 'Price',
'priceperday' => 'Price Per Day',
'pricepermonth' => 'Monthly Price',
'salespacks' => 'Packages on sale',
'gotonextpinc' => 'Move to the next product in this category',
'tocatpage' => "Category Page &gt;&gt;",
'ppss' => 'Products: ',
'nopsincc' => 'No products were added to your cart yet.',
'removep' => 'Are you sure you would like to remove this product?',
'noppsinccs' => 'No Products available',
'nopppccincc' => 'No Packages available',



'no_cart_idfound' => 'Sorry, We could not locate your cart. Please contact us.',
'no_cartcontents_idfound' => 'Sorry, There are no items found in your cart.',
'please_choose_pickup' => 'Sorry, Please choose the shipping method.',
'please_choose_dest' => 'Sorry, Please choose your destination.',
'please_complete_to_register' => 'Sorry, In order to proccess your order you must provide us with your Username, Password, Email and Phone Number',
'err_no_username' => 'Please fill in the user name field',
'err_long_username' => 'User name is too long, Please shorten it to 32 chars',
'err_no_password' => 'Please fill in the password field',
'err_long_password' => 'Password is too long, Please shorten it to 32 chars',
'err_email' => 'The email provided is invalid',
'err_user_exists' => 'Sorry, The chosen user name is already is use. Please choose another one.',
'err_email_exists' => 'Sorry, That email is already in use. Please choose another one.',
'please_complete_to_name' => 'Please fill in the user name field',
'please_complete_to_pass' => 'Please fill in the password field',
'please_complete_to_email' => 'Please fill in the email field',
'please_complete_to_phone' => 'Please fill in the phone field',
'please_complete_to_city' => 'Please fill in the city field',
'please_complete_to_address' => 'Please fill in the address field',
'please_complete_to_fname' => 'Please fill in the first name field',
'baskettitle' => 'Cart',
'creditwasnotcharged' => "The order was completed and added. However there was a problem charging the credit card given. You will be contacted by our sales representative to confirm the payment. The error returned was: '%s'",
'hotlinks_title' => 'View Category:',

'credit1' => 'Please fill in the following',
'credit2' => 'Credit Card Number',
'credit3' => 'Experation Date',
'credit4' => 'First Name',
'credit8' => 'Last Name',
'credit5' => 'CVV Number',
'credit6' => 'Credit Card Type',

'month1' => '01 - Jan',
'month2' => '02 - Feb',
'month3' => '03 - Mar',
'month4' => '04 - Apr',
'month5' => '05 - May',
'month6' => '06 - Jun',
'month7' => '07 - Jul',
'month8' => '08 - Aug',
'month9' => '09 - Sep',
'month10' => '10 - Oct',
'month11' => '11 - Nov',
'month12' => '12 - Dec',

'year1' => '2008',
'year2' => '2009',
'year3' => '2010',
'year4' => '2011',
'year5' => '2012',
'year6' => '2013',

'whatisthis' => "What's that?",

'ccerror004' => 'Credit Card was declined',
'ccerror006' => 'CVV Number is invalid',
'ccerror033' => 'Credit Card Number is invalid',
'ccerror036' => 'Credit Card expired',
'ccerror057' => 'Please specify credit card number',
'ccerror062' => 'Transaction type is invalid',
'ccerror063' => 'Transaction Code is invalid',
'ccerror064' => 'Credit card type is not supported',
'ccerror065' => 'Currency type is invalid',

'card1' => 'Isracard',
'card2' => 'VISA',
'card3' => 'MasterCard',
'card4' => 'American Express',
'card5' => 'JCB',
'card6' => 'Dinners',
'payments' => 'Payments',
'taxincluded' => 'Includes Tax',
'moneywillbeadded' => 'To the final price there will be an additional amount added for delivery option <span style="color:#b18d3f">%s</span> with a total of <span style="color:#b18d3f">%s</span> Nis including tax',
'pispur' => 'Purchasable Product',
'desttitle' => 'Destination',
'dest0' => 'Choose Destination',

'prev_title_word' => 'Previous Product',
'next_title_word' => 'Next Product',

'hotstuff_links1' => 'Rent A SAGEWAY',
'hotstuff_links2' => 'Rent A Generator',
'hotstuff_links3' => 'Rent A Cellular Modem',
'hotstuff_links4' => 'Rent A Satellite Phone',
'hotstuff_links5' => 'Rent A Bike',
'hotstuff_links6' => 'Rent Projectors',
'bottom_links1' => 'Rent A Projector',
'bottom_links2' => 'Rent A GPS',
'bottom_links3' => 'Rent Computers',
'bottom_links4' => 'Rent A Satellite Phone',
'bottom_links5' => 'Rent A Cellular Modem',
'bottom_links6' => 'Global Sim Cards',
'bottom_links7' => 'Rent A Generator',
'bottom_links8' => 'Rent Console Games',
'bottom_links9' => 'Rent TV',
'bottom_links10' => 'Rent A Bike',
'bottom_links11' => 'Rent A SAGEWAY',
'bottom_links12' => 'Rent A Camera',
'bottom_links13' => 'Rent An Electronic Enhancement',
'onlinechatsupport' => 'Live Chat Online',
'offlinechatsupport' => 'Live Chat Offline',
'leavesubject' => 'Subject',
'leavecomment' => 'Comment',

'creditcardvalidtext' => "Fill in your personal details and the desired shipment address.<br />You can pay online using our secured transaction system or choose to pay by phone, <br />Once the order will be submitted a customer representative will contact you regarding the payment if needed.<br />
<b>To complete click on the 'Check Out Now' button.</b> <br />You will receive 1) Order Confirmation 2) Contract Agreement 3) Invoice for your order if you choose to pay online.<br /> The entire site is encrypted and secured under an SSL Certificate, All information provided is destroyed upon order completion.",
'purchase' => 'Purchase',
);


$lang['aboutustext1'] = "<b>אודות אתר רנט סנטר </b>
<br />
אתר רנט סנטר מבית WebTarget LTD. הוא אתר שבו כל המוצרים מוצעים להשכרה
<br />
באתר תמצאו מגוון ענק של מוצרים להשכרה,לעסק ,לבית ,לאירוע ולחופשה שלכם.<br /> ההזמנות נשלחות לביתכם או נאספות על ידכם תוך 24 שעות מעת ביצוע ההזמנה . ";
$lang['whytorent'] = "למה להשכיר בכלל?";

$lang['why_to_rent_text'] = 'השכרה חוסכת לכם הוצאה ניכרת הכרוכה ברכישת מוצר שאתם זקוקים לו באופן חד פעמי או לעיתים נדירות,<br />
 במקרים רבים תגלו שהשכרה משתלמת עבורכם לעומת רכישה.<br />
<br />
 נכון שהמוצר הוא שלכם רק לתקופת ההשכרה אבל הבעלות על המוצר,<br />
 לא תהפוך את המוצר למהנה או שימושי יותר עבורכם, להיפך ברוב המקרים מדובר בכאב ראש לא קטן,<br />
 תצטרכו לחפש, להשוות מחירים, לפנות לו מקום, לתחזק אותו ועוד. כמו שנאמר: "מרבה נכסים מרבה דאגות". לעומת זאת,<br />
 בהשכרה תקבלו את המוצר עד הבית תוך 24 שעות,<br />
 תיהנו מתמיכה טכנית ונציגי שירות שיעמדו לרשותכם 24 שעות ביממה ויבטיחו הנאה וזמינות מלאה של המוצר עבורך.<br />';

$lang['moreadv'] = "יתרונות נוספים";

$lang['additional_benefits_text'] = '<u>תחזוקה :</u><br /><br />

השכרה מבטיחה לכם "ראש שקט".<br />
אתם מקבלים מוצר תקין ועדכני עם שירות ותמיכה עד הבית, <br />
אתם לא צריכים לדאוג לטיפול השוטף במוצר כגון עדכון תוכנות וגרסאות או בציוד מכני, טיפולים תקופתיים ועוד. <br /><br />

<u>פחת וירידת מחירים :</u><br /><br />

רכישה של מוצר מהווה השקעה כספית במוצר,<br />
שתוך זמן קצר כבר לא יהיה שווה הרבה (כי נכנסו לשוק דגמים חדשים או שהסינים התחילו ליצר אותו).<br />
בהשכרה אתם מבטיחים לעצמכם מוצר חדיש ועדכני ותמורה הולמת לכספכם בכך<br /><br />
 שאתם משלמים עבור השימוש העכשווי ולא על שימוש עתידי שאולי לא יהיה . <br /><br />

<u>הוצאה מוכרת במלואה לעסקים:</u><br /><br />

יתרון חשוב לעסקים וארגונים,<br />
ההוצאה עבור השכרה מוכרת לכם במלואה ובמיידית  לעומת רכישה שרק חלק ממנה יוכר לכם במהלך שנת המס. <br /><br />

<u>צרכנות חכמה</u><br /><br />

מתלבטים אם לרכוש מוצר?<br />
השכרת המוצר תאפשר לכם לבדוק אם המוצר מתאים לכם לפני שתרכשו אותו ובכך  <br />
 להימנע מרכישת מוצר שאולי אתם לא רוצים או לא צריכים באמת.<br />  <br />

<u>תרומה קטנה לסביבה ירוקה יותר</u><br /><br />

כשמשכירים מוצר, משכירים אותו לצורך קונקרטי ונמנעים מרכישה של מוצר שייצורו כרוך בזיהום אוויר ובסופו של דבר <br />
"ישכב" רוב הזמן בבית. נכון שגם אנחנו רוכשים את המוצר אבל בהנחה שאצלנו "העסקים טובים", <br />
המוצר ינוצל במלואו בכך שיסתובב אצל הרבה לקוחות = הרבה אנשים שלא רכשו <br />
את המוצר = הרבה מוצרים  שלא ייצרו = הרבה פחות זיהום אוויר! <br /><br />';

$lang['why_to_rent_here_text'] = 'מגוון המוצרים באתר וחבילות המוצרים המורכבות ממספר מוצרים משלימים,<br />
מבטיח שכמעט תמיד תמצאו את המוצר המתאים ביותר עבורכם גם בכמויות ובדיל אטרקטיבי במיוחד  <br />
המוצרים המוצעים להשכרה באתר נבחנו בקפידה ע"י הצוות המקצועי שלנו ונמצאו כידידותיים אמינים ואיכותיים.<br />
המוצרים נמצאים תחת אחריות ולכן לא תחויבו במקרה שהמוצר התקלקל למעט שבירה, הרטבה או גניבה של המוצר וכדומה.<br />';

$lang['why_to_rent_here_header'] = "למה להשכיר אצלנו?";

$lang['aboutus_contact_us_text'] = <<<EOF

<b><u>סניפים:</u></b><br />
<u>תל אביב</u><br />
כתובת: יוסף קארו 3 (בית "קלקא", מנחם בגין 116, למטה)<br />
טלפון: 9559*, 03-5621037<br />
שעות פעילות: ימי א'-ה' 09:00-23:00, יום ו' 09:00-15:00
<br /><br />
<u>ירושלים</u><br />
כתובת: המלך דוד 19.<br />
טלפון: 9559*, 077-3009341/2<br />
שעות פעילות: ימי א'-ה' 09:00-19:30, יום ו' 09:00-14:00
<br /><br />
<u>חיפה</u><br />
בקרוב ייפתח סניף בכרמל!<br /><br />
פקס כללי: 03-7608793 דוא"ל כללי: info@rentcenter.co.il<br />
<br /><br />

EOF;

?>