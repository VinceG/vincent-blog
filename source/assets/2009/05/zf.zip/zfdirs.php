<?php

$components = array(

		'Introduction',
        'Zend_Acl',
        'Zend_Application',
        'Zend_Amf',
        'Zend_Auth',

        'Zend_Cache',
        'Zend_Captcha',
        'Zend_CodeGenerator',
        'Zend_Config',
        'Zend_Config_Writer',
        'Zend_Console_Getopt',

        'Zend_Controller',
        'Zend_Currency',
        'Zend_Date',
        'Zend_Db',
        'Zend_Debug',
        'Zend_Dojo',

        'Zend_Dom',
        'Zend_Exception',
        'Zend_Feed',
        'Zend_File',
        'Zend_Filter',
        'Zend_Filter_Input',

        'Zend_Form',
        'Zend_Gdata',
        'Zend_Http',
        'Zend_Infocard',
        'Zend_Json',
        'Zend_Layout',

        'Zend_Ldap',
        'Zend_Loader',
        'Zend_Locale',
        'Zend_Log',
        'Zend_Mail',
        'Zend_Measure',

        'Zend_Memory',
        'Zend_Mime',
        'Zend_Navigation',
        'Zend_OpenId',
        'Zend_Paginator',
        'Zend_Pdf',

        'Zend_ProgressBar',
        'Zend_Reflection',
        'Zend_Registry',
        'Zend_Rest',
        'Zend_Search_Lucene',
        'Zend_Server_Reflection',

        'Zend_Service_Akismet',
        'Zend_Service_Amazon',
        'Zend_Service_Amazon_Ec2',
        'Zend_Service_Amazon_S3',
        'Zend_Service_Audioscrobbler',
        'Zend_Service_Delicious',

        'Zend_Service_Flickr',
        'Zend_Service_Nirvanix',
        'Zend_Service_ReCaptcha',
        'Zend_Service_Simpy',
        'Zend_Service_SlideShare',
        'Zend_Service_StrikeIron',

        'Zend_Service_Technorati',
        'Zend_Service_Twitter',
        'Zend_Service_Yahoo',
        'Zend_Session',
        'Zend_Soap',
        'Zend_Tag',

        'Zend_Test',
        'Zend_Text',
        'Zend_Timesync',
        'Zend_Tool_Framework',
        'Zend_Tool_Project',
        'Zend_Translate',

        'Zend_Uri',
        'Zend_Validate',
        'Zend_Version',
        'Zend_View',
        'Zend_Wildfire',
        'Zend_XmlRpc',

        'ZendX_Console_Process_Unix',
        'ZendX_JQuery',
        'Requirements',
        'Coding Standard',
        'Performance Guide',
        'Copyright Information',
        
);

$path = 'zf';

foreach ($components as $component)
{
	@mkdir($path . DIRECTORY_SEPARATOR . $component, 0777);
}
	
echo "Done!";