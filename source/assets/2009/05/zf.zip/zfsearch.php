<?php

$search = array(

		'href="introduction.',
        'href="zend.acl.',
        'href="zend.application.',
        'href="zend.amf.',
        'href="zend.auth.',

        'href="zend.cache.',
        'href="zend.captcha.',
        'href="zend.codegenerator.',
        'href="zend.config.',
        'href="zend.console.',

        'href="zend.controller.',
        'href="zend.currency.',
        'href="zend.date.',
        'href="zend.db.',
        'href="zend.debug.',
        'href="zend.dojo.',

        'href="zend.dom.',
        'href="zend.exception.',
        'href="zend.feed.',
        'href="zend.file.',
        'href="zend.filter.',

        'href="zend.form.',
        'href="zend.gdata.',
        'href="zend.http.',
        'href="zend.infocard.',
        'href="zend.json.',
        'href="zend.layout.',

        'href="zend.ldap.',
        'href="zend.loader.',
        'href="zend.locale.',
        'href="zend.log.',
        'href="zend.mail.',
        'href="zend.measure.',

        'href="zend.memory.',
        'href="zend.mime.',
        'href="zend.navigation.',
        'href="zend.openid.',
        'href="zend.paginator.',
        'href="zend.pdf.',

        'href="zend.progressbar.',
        'href="zend.reflection.',
        'href="zend.registry.',
        'href="zend.rest.',
        'href="zend.search.lucene.',
        'href="zend.server.reflection.',
        'href="zend.server.',

        'href="zend.service.',
        'href="zend.session.',
        'href="zend.soap.',
        'href="zend.tag.',

        'href="zend.test.',
        'href="zend.text.',
        'href="zend.timesync.',
        'href="zend.tool.',
        'href="zend.translate.',

        'href="zend.uri.',
        'href="zend.validate.',
        'href="zend.version.',
        'href="zend.view.',
        'href="zend.wildfire.',
        'href="zend.xmlrpc.',

        'href="requirements.',
        'href="coding-standard.',
        'href="performance.',
        'href="copyrights.',
        'href="the.index.',
        'href="index.',
        
        # Zend X
        'href="zendx.console.',
        'href="zendx.jquery.',
        'href="the.indexx.',
        'href="indexx.',
        
);

$replace = array(

		'href="Introduction/introduction.',
        'href="Zend_Acl/zend.acl.',
        'href="Zend_Application/zend.application.',
        'href="Zend_Amf/zend.amf.',
        'href="Zend_Auth/zend.auth.',

        'href="Zend_Cache/zend.cache.',
        'href="Zend_Captcha/zend.captcha.',
        'href="Zend_CodeGenerator/zend.codegenerator.',
        'href="Zend_Config/zend.config.',
        'href="Zend_Console_Getopt/zend.console.',

        'href="Zend_Controller/zend.controller.',
        'href="Zend_Currency/zend.currency.',
        'href="Zend_Date/zend.date.',
        'href="Zend_Db/zend.db.',
        'href="Zend_Debug/zend.debug.',
        'href="Zend_Dojo/zend.dojo.',

        'href="Zend_Dom/zend.dom.',
        'href="Zend_Exception/zend.exception.',
        'href="Zend_Feed/zend.feed.',
        'href="Zend_File/zend.file.',
        'href="Zend_Filter/zend.filter.',

        'href="Zend_Form/zend.form.',
        'href="Zend_Gdata/zend.gdata.',
        'href="Zend_Http/zend.http.',
        'href="Zend_Infocard/zend.infocard.',
        'href="Zend_Json/zend.json.',
        'href="Zend_Layout/zend.layout.',

        'href="Zend_Ldap/zend.ldap.',
        'href="Zend_Loader/zend.loader.',
        'href="Zend_Locale/zend.locale.',
        'href="Zend_Log/zend.log.',
        'href="Zend_Mail/zend.mail.',
        'href="Zend_Measure/zend.measure.',

        'href="Zend_Memory/zend.memory.',
        'href="Zend_Mime/zend.mime.',
        'href="Zend_Navigation/zend.navigation.',
        'href="Zend_OpenId/zend.openid.',
        'href="Zend_Paginator/zend.paginator.',
        'href="Zend_Pdf/zend.pdf.',

        'href="Zend_ProgressBar/zend.progressbar.',
        'href="Zend_Reflection/zend.reflection.',
        'href="Zend_Registry/zend.registry.',
        'href="Zend_Rest/zend.rest.',
        'href="Zend_Search_Lucene/zend.search.lucene.',
        'href="Zend_Server_Reflection/zend.server.reflection.',
        'href="Zend_Server/zend.server.',

        'href="Zend_Service/zend.service.',
        'href="Zend_Session/zend.session.',
        'href="Zend_Soap/zend.soap.',
        'href="Zend_Tag/zend.tag.',

        'href="Zend_Test/zend.test.',
        'href="Zend_Text/zend.text.',
        'href="Zend_Timesync/zend.timesync.',
        'href="Zend_Tool/zend.tool.',
        'href="Zend_Translate/zend.translate.',

        'href="Zend_Uri/zend.uri.',
        'href="Zend_Validate/zend.validate.',
        'href="Zend_Version/zend.version.',
        'href="Zend_View/zend.view.',
        'href="Zend_Wildfire/zend.wildfire.',
        'href="Zend_XmlRpc/zend.xmlrpc.',

        'href="Requirements/requirements.',
        'href="Coding Standard/coding-standard.',
        'href="Performance Guide/performance.',
        'href="Copyright Information/copyrights.',
        'href="Introduction/the.index.',
        'href="Introduction/index.',
        
        # Zend X
        'href="ZendX_Console_Process_Unix/zendx.console.',
        'href="ZendX_JQuery/zendx.jquery.',
        'href="ZendX/the.indexx.',
        'href="ZendX/indexx.',
        
);



$path = 'zf';
$files = directoryToArray($path, true);

foreach ($files as $file)
{
	ReplaceWords($file);
}
echo "<h1>Done!</h1>";


#################################################################


function vardumpfile( $file )
{
	if(!is_file($file))
	{
		echo "<h3>File '{$file}' Does not exists</h3>";
		return;
	}
	
	$text = file_get_contents($file);
	
	print "<pre>";
	print $text;
	print "</pre>";
}

function ReplaceWords( $file )
{
	global $search, $replace;
	if(!is_file($file))
	{
		echo "<h3>File '{$file}' Does not exists</h3>";
		return;
	}
	
	
	$text = file_get_contents($file);
	
	if($text)
	{
		$text = str_replace($search, $replace, $text);
		$text = ReplaceSymbols($text);
	}
	
	file_put_contents($file, $text);
	
	echo "<h2>File '{$file}' PARSED!</h2>";
	return;
	
}

function ReplaceSymbols( $text )
{
	$text = preg_replace( '~#Zend_([a-z]+)/~', '#', $text);
	return $text;
}

function directoryToArray($directory, $recursive) {
	$array_items = array();
	if ($handle = opendir($directory)) {
		while (false !== ($file = readdir($handle))) {
			if ($file != "." && $file != "..") {
				if (is_dir($directory. "/" . $file)) {
					if($recursive) {
						$array_items = array_merge($array_items, directoryToArray($directory. "/" . $file, $recursive));
					}
					$file = $directory . "/" . $file;
					$array_items[] = preg_replace("/\/\//si", "/", $file);
				} else {
					$file = $directory . "/" . $file;
					$array_items[] = preg_replace("/\/\//si", "/", $file);
				}
			}
		}
		closedir($handle);
	}
	$items = array();
	foreach($array_items as $item)
	{
		if(is_file($item))
		{
			$items[] = $item;
		}
	}
	return $items;
}
